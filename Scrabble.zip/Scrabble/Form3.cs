﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scrabble
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 sistema = new Form1();
            sistema.ShowDialog();
            
            this.Close();

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Drag and drop letters to create a word. When your word is completed click Done");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I'm Asha Sluga Malnar \n 4.RB \n This is my final project Scrabble");
        }
    }
}
